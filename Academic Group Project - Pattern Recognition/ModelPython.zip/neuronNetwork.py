import os
import numpy as np
import etap3Modyfikacja.generatedImages
from PIL import Image
from keras.utils import np_utils
from keras.models import Sequential
from keras.layers import Dense
from keras.models import load_model
from keras.optimizers import Adam

num_classes = 3  # Liczba klas (X, O, ignore)
x_train = etap3Modyfikacja.generatedImages.x_train
x_test = etap3Modyfikacja.generatedImages.x_test
y_train = etap3Modyfikacja.generatedImages.y_train
y_test = etap3Modyfikacja.generatedImages.y_test

x_test_size = etap3Modyfikacja.generatedImages.x_size_test

y_train_categorical = np_utils.to_categorical(y_train, num_classes)
y_test_categorical = np_utils.to_categorical(y_test, num_classes)

model_path = "model.h5"

if os.path.exists(model_path):
    model = load_model(model_path)
else:
    model = Sequential()
    model.add(Dense(4, activation='relu', input_shape=(16,)))
    model.add(Dense(3, activation='softmax'))

    model.compile(loss='categorical_crossentropy',
                  optimizer=Adam(),
                  metrics=['accuracy'])
    model.summary()

    history = model.fit(x_train, y_train_categorical,
                        batch_size=256,
                        epochs=40,
                        verbose=1,
                        validation_data=(x_test, y_test_categorical))
    model.save(model_path)
#
model_path = "model.h5"
weights_path = "wagi.txt"

# Zapisywanie wag do pliku
weights = model.get_weights()
with open(weights_path, 'w') as file:
    for weight in weights:
        rounded_weight = np.round(weight, decimals=8).astype(float)
        formatted_weight = np.array2string(rounded_weight, separator=',', suppress_small=True)
        file.write(formatted_weight + '\n')

def saveResults():
    for j in range(250):
        example = x_test[j]
        example = example.reshape(1, -1) # Dopasowanie ksztaltu przykladu testowego

        prediction = model.predict(example)
        predicted_class = np.argmax(prediction)

        # Pobranie prawdopodobienstwa dla kazdej klasy
        class_probabilities = prediction[0]
        numbers = ' '.join([str(num) for num in x_test[j]])
        print(f"Wynik dla macierzy: {numbers}")

        if predicted_class == 0:
            print("Ten obraz przedstawia X!")
        elif predicted_class == 1:
            print("Ten obraz przedstawia O!")
        else:
            print("Obraz przedstawia inny wzorzec")
        print("Prawdopodobienstwa wystapienia:")
        print(f"X: {class_probabilities[0]:.5f}")
        print(f"O: {class_probabilities[1]:.5f}")
        print(f"Inny: {class_probabilities[2]:.5f}")
        print()  # Dodanie pustej linii dla czytelnosci

def classifyImage(image_path):
    # Wczytanie modelu
    model = load_model(model_path)

    # Wczytanie obrazu
    img = Image.open(image_path)
    img_arr = np.array(img)

    # Przeksztalcenie obrazu na macierz jednowymiarowa
    normalized_img = (img_arr / 255) - 0.5
    flattened_img = normalized_img.flatten()
    example = flattened_img.reshape(1, -1)

    # Klasyfikacja obrazu
    prediction = model.predict(example)
    predicted_class = np.argmax(prediction)
    class_probabilities = prediction[0]

    # Mapowanie etykiet na nazwy klas
    labels = ['X', 'O', 'ignore']
    predicted_label = labels[predicted_class]

    # Wyswietlanie wynikow
    print(f"Wynik dla obrazu: {image_path}")
    print(f"Obraz przedstawia wzorzec: {predicted_label}")
    print("Prawdopodobienstwa wystapienia:")
    for label, probability in zip(labels, class_probabilities):
        print(f"{label}: {probability:.5f}")
    print()  # Dodaj pusta linie dla czytelnosci

# Przyklad uzycia
# Indywidualna sciezka do lokalizacji projektu
path = "C:/Users/Kuba/Documents/Programming/SYCYF_23L_Zespol13"
# Sciezka do obrazu
image_path = path + "/etap3Modyfikacja/O_images/test/image1609.png"
saveResults()
classifyImage(image_path)