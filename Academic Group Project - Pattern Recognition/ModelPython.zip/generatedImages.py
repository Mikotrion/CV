import itertools
import cv2
import os
import shutil
import random
from PIL import Image
import numpy as np

def generateImages():
    # Utworzenie listy wszystkich mozliwych kombinacji obrazow 4x4 piksele
    # skladajacych sie z kwadratow czarnych i bialych
    combinations = list(itertools.product([0, 1], repeat=16))

    # Stworzenie folderu, jesli jeszcze nie istnieje
    if not os.path.exists('generatedImages'):
        os.makedirs('generatedImages')

    # Iterowanie przez kazda kombinacje i zapisanie jej jako plik .png
    # w folderze generatedImages
    for i, combo in enumerate(combinations):
        # Konwersja kombinacji na macierz 4x4
        img = np.array(combo).reshape(4, 4)

        # Zmiana macierzy na obraz czarno-bialy i zapisanie go do pliku
        filepath = f'generatedImages/image{i}.png'
        img *= 255
        cv2.imwrite(filepath, img)

def sortImages():
    X = np.array([
        [1, 0, 0, 1],
        [0, 1, 1, 0],
        [0, 1, 1, 0],
        [1, 0, 0, 1]
    ])
    O = np.array([
        [0, 1, 1, 0],
        [1, 0, 0, 1],
        [1, 0, 0, 1],
        [0, 1, 1, 0],
    ])

    # Utworzenie folderow
    os.makedirs("X_images/train", exist_ok=True)
    os.makedirs("X_images/test", exist_ok=True)
    os.makedirs("O_images/train", exist_ok=True)
    os.makedirs("O_images/test", exist_ok=True)
    os.makedirs("ignore_images/train", exist_ok=True)
    os.makedirs("ignore_images/test", exist_ok=True)

    # Przetworzenie wszystkich plikow PNG w folderze generatedImages
    for filename in os.listdir("generatedImages"):
        if filename.endswith(".png"):
            filepath = os.path.join("generatedImages", filename)

            # Przetworzenie obrazu na macierz binarna
            img = cv2.imread(filepath, cv2.IMREAD_GRAYSCALE)
            threshold_value = 128
            max_value = 255
            ret, bin_matrix = cv2.threshold(img, threshold_value, max_value,
            cv2.THRESH_BINARY)
            bin_matrix = np.where(bin_matrix == 255, 0, 1)

            # Zliczanie ilosci pikseli w macierzy test, ktore sa takie same
            # jak w macierzy X lub O
            matching_X = np.sum(X == bin_matrix)
            matching_O = np.sum(O == bin_matrix)

            # Rozpoznanie wzoru i zapisanie pliku w odpowiednim folderze
            if matching_X >= 13:
                if random.random() < 0.7:
                    pattern = "X_images/train"
                else:
                    pattern = "X_images/test"
            elif matching_O >= 13:
                if random.random() < 0.7:
                    pattern = "O_images/train"
                else:
                    pattern = "O_images/test"
            else:
                if random.random() < 0.7:
                    pattern = "ignore_images/train"
                else:
                    pattern = "ignore_images/test"

            shutil.copy(filepath, pattern)

# Funkcja ktora wczytuje obrazy z pliku do ktorego podamy sciezke i przeksztalca je
# na macierz jednowymiarowa,normalizuje piksele obrazu do przedzialu od -0.5 do 0.5
def loadImages(path):
    images = []
    filenames = sorted(os.listdir(path))  # Sortowanie plikow alfabetycznie
    for filename in filenames:
        img = Image.open(os.path.join(path, filename))
        img_arr = np.array(img)
        normalized_img = (img_arr / 255) -0.5
        flattened_img = normalized_img.flatten()
        images.append(flattened_img)
    return np.array(images)

generateImages()
sortImages()

# Indywidualna sciezka do lokalizacji projektu
path = "C:/Users/Kuba/Documents/Programming/SYCYF_23L_Zespol13"

x_train = loadImages(path+"/etap3Modyfikacja/X_images/train")
o_train = loadImages(path+"/etap3Modyfikacja/O_images/train")
ignore_train = loadImages(path+"/etap3Modyfikacja/ignore_images/train")
x_test = loadImages(path+"/etap3Modyfikacja/X_images/test")
o_test = loadImages(path+"/etap3Modyfikacja/O_images/test")
ignore_test = loadImages(path+"/etap3Modyfikacja/ignore_images/test")

x_size_train = int(x_train.size/16)
o_size_train = int(o_train.size/16)
ignore_size_train = int(ignore_train.size/16)
x_size_test = int(x_test.size/16)
o_size_test = int(o_test.size/16)
ignore_size_test = int(ignore_test.size/16)

# Tworzenie etykiet dla danych treningowych
y_train = np.concatenate((
    np.zeros(x_size_train, dtype=int),
    np.ones(o_size_train, dtype=int),
    np.full(ignore_size_train, 2, dtype=int)
), axis=0)

# Tworzenie etykiet dla danych testowych
y_test = np.concatenate((
    np.zeros(x_size_test, dtype=int),
    np.ones(o_size_test, dtype=int),
    np.full(ignore_size_test, 2, dtype=int)
), axis=0)

# Polaczenie danych treningowych
x_train = np.concatenate((x_train, o_train, ignore_train), axis=0)

# Polaczenie danych testowych
x_test = np.concatenate((x_test, o_test, ignore_test), axis=0)